//program no 1 
   #include <iostream>
using namespace std;

int main() {
  cout << "Hello World!";
  return 0;
}
